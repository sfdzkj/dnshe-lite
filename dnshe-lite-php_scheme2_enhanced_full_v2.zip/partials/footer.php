<?php
// partials/footer.php
?>
    </div>
  </main>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
