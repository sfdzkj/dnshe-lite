<?php
$cfg = require __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
require_once __DIR__ . '/../lib/security.php';
require_once __DIR__ . '/../lib/db.php';
require_once __DIR__ . '/../lib/log.php';

$u = require_admin($cfg);
$db = db($cfg);
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['act'] ?? '';
    if ($act === 'create') {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $role = (string)($_POST['role'] ?? 'user');
        if (!password_strong_enough($password)) {
            $msg = '密码强度不足';
        } else {
            try {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                db_exec($db, 'INSERT INTO users(username,password_hash,role,disabled,must_change_password,created_at) VALUES(:u,:p,:r,0,1,:t)', [
                    'u'=>$username,'p'=>$hash,'r'=>$role,'t'=>time()
                ]);
                add_log($cfg, (int)$u['id'], null, null, 'system', 'create_user', 'success', $username);
                $msg = '创建成功（首次登录强制改密）';
            } catch (Throwable $e) {
                $msg = '创建失败：' . $e->getMessage();
            }
        }
    }
    if ($act === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $disabled = (int)($_POST['disabled'] ?? 0);
        if ($id) {
            db_exec($db, 'UPDATE users SET disabled=:d WHERE id=:id AND role<>"admin"', ['d'=>$disabled,'id'=>$id]);
            add_log($cfg, (int)$u['id'], null, null, 'system', 'toggle_user', 'success', (string)$id);
        }
        header('Location: index.php?page=users');
        exit;
    }
}

$users = db_all($db, 'SELECT id,username,role,disabled,created_at,last_login_at FROM users ORDER BY id DESC');

require __DIR__ . '/../partials/header.php';
require __DIR__ . '/../partials/sidebar.php';
?>
<h3>用户管理</h3>
<?php if($msg): ?><div class="alert alert-info"><?= h($msg) ?></div><?php endif; ?>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="card shadow-sm"><div class="card-body">
      <h5>新增用户</h5>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
        <input type="hidden" name="act" value="create">
        <div class="mb-2"><label class="form-label">用户名</label><input class="form-control" name="username" required></div>
        <div class="mb-2"><label class="form-label">初始密码（首次登录强制改密）</label><input type="password" class="form-control" name="password" required></div>
        <div class="mb-2"><label class="form-label">角色</label><select class="form-select" name="role"><option value="user">普通用户</option><option value="admin">管理员</option></select></div>
        <button class="btn btn-primary">创建</button>
      </form>
    </div></div>
  </div>
  <div class="col-lg-7">
    <div class="card shadow-sm"><div class="card-body">
      <h5>用户列表</h5>
      <div class="table-responsive">
        <table class="table table-striped align-middle">
          <thead><tr><th>ID</th><th>用户名</th><th>角色</th><th>状态</th><th>创建</th><th>最近登录</th><th>操作</th></tr></thead>
          <tbody>
            <?php foreach($users as $x): ?>
            <tr>
              <td><?= (int)$x['id'] ?></td>
              <td><?= h($x['username']) ?></td>
              <td><?= h($x['role']) ?></td>
              <td><?= (int)$x['disabled']===1?'<span class="badge bg-secondary">禁用</span>':'<span class="badge bg-success">正常</span>' ?></td>
              <td class="small"><?= date('Y-m-d', (int)$x['created_at']) ?></td>
              <td class="small"><?= $x['last_login_at']?date('Y-m-d H:i', (int)$x['last_login_at']):'-' ?></td>
              <td>
                <?php if($x['role']!=='admin'): ?>
                  <form method="post" style="display:inline" onsubmit="return confirmAction('确认变更用户状态？')">
                    <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
                    <input type="hidden" name="act" value="toggle">
                    <input type="hidden" name="id" value="<?= (int)$x['id'] ?>">
                    <input type="hidden" name="disabled" value="<?= (int)$x['disabled']===1?0:1 ?>">
                    <button class="btn btn-sm btn-outline-warning"><?= (int)$x['disabled']===1?'启用':'禁用' ?></button>
                  </form>
                <?php else: ?><span class="text-muted small">-</span><?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div></div>
  </div>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>
